//
//  BrowseAllInstalledApplication.h
//  iosAsst
//
//  Created by peter_peng on 14-10-10.
//  Copyright (c) 2014年 www.iphonezs.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BrowseAllInstalledApplication : NSObject
+ (NSMutableArray *)browseInstalledAppList;
@end
