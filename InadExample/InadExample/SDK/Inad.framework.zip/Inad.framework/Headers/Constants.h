//
//  Constants.h
//  Inad
//
//  Created by Hai Pham on 8/2/16.
//  Copyright © 2016 vietkite. All rights reserved.
//

#import <Foundation/Foundation.h>

#define DEBUG true
#define ROOT @"http://210.211.118.11:9000/"
#define INITIALIZE @"initialize?test=%@"
#define REQUEST @"request?test=%@"
#define RESULT @"result?test=%@"
#define IOS @"IOS"
#define DB_NAME    @"adnetwork.db"
#define ADNETWORK_DB @"adnetwork.db"
#define VenderUUID @"VenderUUID"

@interface Constants : NSObject

@end
